package com.example.linas.a4lab;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button buttonGo = (Button) findViewById(R.id.buttonGo);
        buttonGo.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                EditText editTextUrl = (EditText) findViewById(R.id.editTextUrl);
                String url = editTextUrl.getText().toString();

                WebView webView = (WebView) findViewById(R.id.webView);
                webView.loadUrl(url);
            }
        });
    }
}
